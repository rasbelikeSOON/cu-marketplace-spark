
const SellerDashboard = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold">Seller Dashboard</h1>
      <p>Track orders, manage stock, and receive notifications.</p>

      {/* Order Tracking */}
      <section>
        <h2 className="text-xl font-semibold">Your Orders</h2>
        <p>Track your received and pending orders.</p>
      </section>

      {/* Stock Management */}
      <section>
        <h2 className="text-xl font-semibold">Stock Management</h2>
        <p>Monitor inventory levels and update products.</p>
      </section>

      {/* Notifications */}
      <section>
        <h2 className="text-xl font-semibold">Messages & Notifications</h2>
        <p>Get notified when a customer sends a message.</p>
      </section>
    </div>
  );
};

export default SellerDashboard;
