
type CategoriesSectionProps = {
  onCategoryChange?: (categoryId: number) => void;
};

const handleCategoryClick = (categoryId: number, onCategoryChange?: (categoryId: number) => void) => {
  if (onCategoryChange) {
    onCategoryChange(categoryId);
  } else {
    window.location.href = `/category/${categoryId}`;
  }
};
