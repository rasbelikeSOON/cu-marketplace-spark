
<Button size="lg" onClick={() => window.location.href = "/shop"}>Shop Now</Button>
