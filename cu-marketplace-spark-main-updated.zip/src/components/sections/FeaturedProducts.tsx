
<Button variant="outline" onClick={() => window.location.href = "/product-listing"}>View More</Button>
